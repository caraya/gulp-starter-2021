Whether it's used for packaging or not, you should also consider the benefit they have for user experience. in web applications. 

For different scenarios of how to leverage service workers look at Jake Archibald's [offline cookbook](http://jakearchibald.com/2014/offline-cookbook/)

While we can do compression and extraction I think that's better server in a shared worker and the service worker should be allowed to do what it does best: provide an offline experience with web content. 
