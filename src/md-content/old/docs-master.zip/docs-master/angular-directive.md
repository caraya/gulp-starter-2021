---
title: Creating a DE custom directive in AngularJS
date: 2014-10-22
category: Technology
status: draft
---

# Creating a D3 custom directive in AngularJS

## Getting started

### What is AngularJS

### What is D3

### How does it work?

## Building the directive

## Does it work in ebooks?

## How is this different than web components?

One of the biggest things in web development is [Web Components](http://webcomponents.org/) that allow for reusable and 

## Conclusion