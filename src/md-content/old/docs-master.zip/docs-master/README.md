# docs

Writing and documentation written in gfm. Sometimes the preview in Sublime'sMarkdown Extended doesn't know how to handle tables and images So I add it here before putting them on the blog... it also helps when soliciting feedback

This repository exists mostly for feedback and historical purposes. Since I started working with Ulyses and Wordpress (with the Jetpack plugin) I've moved to testing and debugging Markdown directly on the blog. 

If you want to see the results go to [The Publishing Project](http://publishing-project.rivendellweb.net)


