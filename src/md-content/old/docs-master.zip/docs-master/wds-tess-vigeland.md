[vimeo 71523426 w=500]


I remember listening to Tess in 2013 and being amazed. It wasn't just the courage that it took to actually leave but it was how vulnerable that made her and her willingness to share that vulnerability with the audience (us... I was there.)

Can you imagine how hard it is to open yourself like that? Unless I really knew the person I'd never have the courage to do that.... Much less in front of 3000 strangers. I think it was that willingness and the way she told the story that made me really think and question where I was at with life.

A few months later, 1-Nov-2013 I walked in to my director's office and told her I was quitting and that my last day was the 15 of that month. There are a lot of reasons why I chose to leave and I wasn't really ready to tell my coworkers what those reasons where (and Chris and Rob did try to convince me to stay.) 

I wanted something different and I wanted change. I had a pot of money I could dip in as needed and I had a plan or what I wanted to do in that year. I don't know how much of the decision was made at the time I heard Tess speak for the first time. I'll never forget the picture below. 

[caption id="attachment_2954" align="aligncenter" width="300"]<a href="http://rivendellweb.net/blog/wp-content/uploads/2013/07/tess-vigeland.jpg"><img src="http://rivendellweb.net/blog/wp-content/uploads/2013/07/tess-vigeland-300x200.jpg" alt="Tess Vigeland: What the hell are you doing? You&#039;re just being awesome and remarkable" width="300" height="200" class="size-medium wp-image-2954" /></a> Tess Vigeland: What the hell are you doing? You're just being awesome and remarkable[/caption]

It was kinda surprising to see Tess back on stage this year. I wondered what was going on and remembered that a few weeks ago I'd seen that her book was finally being published! She had done it! It seemed it was a different Tess who stood before the audience on Monday... she was relaxed and she was happy (or as happy as you can be when you stand before 3000 people :)

[caption id="attachment_3357" align="aligncenter" width="630"]<a href="http://rivendellweb.net/blog/wp-content/uploads/2015/07/tess-vigeland-wds2015.jpg"><img src="http://rivendellweb.net/blog/wp-content/uploads/2015/07/tess-vigeland-wds2015-768x1024.jpg" alt="Tess Vigeland at WDS2015" width="630" height="840" class="size-large wp-image-3357" /></a> Tess Vigeland at WDS2015[/caption]

It had taken her 2 years of hard work and it paid off... the book is released in August/September (6 weeks) and she had gone out of her comfort zone and had pushed her comfort zone to where it is now.

There is no reason to go when you're ready to do so. I proved that to myself 2 years ago and there is no reason why I can't do it again so what's stopping you other than you stopping yourself?
