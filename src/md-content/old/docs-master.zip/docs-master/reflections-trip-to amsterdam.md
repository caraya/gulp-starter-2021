# SFO to AMS -- Day 1

I'm eriting this on an airplane (a KLM 747) on my way to Amsterdam, one of the first spur of the moment trips I've taken as an adult, and it's just dawning on me... There is no reason why I can't enjoy more of this and do it on my terms.

I was watching Armin Only's Intense roadmovies (recorded while Armin was on his year long tour. The ones that caught my attention, and that I hadn't seen before, were the Brussels and the closing Amsterdam shows. They made me realize something: Why not?

Why not explore the world? It's out there and you're not getting any younger... it's never to late to start but it may be too late not to.

Why not do it on my terms? I like NTT but it's not what I see myself ding for the next 3 to 5 years.... I want to be able to work from wherever I want. I want to have the flexibility to travel and be in places and be able to do. 

I've mentioned before that my work at NTT was not the start of a new stage but a continuation of the exploration I started when I left FireEye. Who are you? What do you want to do? 

I'm far from home yet I feel alive, I feel in control of what I do and where I need to go 

<iframe width="560" height="315" src="https://www.youtube.com/embed/YVxxqOB_Ct0" frameborder="0" allowfullscreen></iframe>

## Schipol Airport

All I can say is wow! It's a city in and of itself


