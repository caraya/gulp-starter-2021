# The future of books, part 2: Context
