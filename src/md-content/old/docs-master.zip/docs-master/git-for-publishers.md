# Git for Publishers

This series will explore GIT, what it is, what options do we have to use it and how can we best leverage the technology in a publishing environment.

# What is GIT

# How can I use git

## Different models and different vendors

## Self Hosted

## Github

## Bitbucket

## Gitlab

# Creating a new project

# Github in detail

## The main project interface

## Concepts and Terminology

### Repository

### Branches

### Issues

### Pull Requests

# Getting Started

## Creating a new project

## *
