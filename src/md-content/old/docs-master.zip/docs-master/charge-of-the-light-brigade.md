```
The Charge of the Light Brigade
1
Half a league, half a league,
Half a league onward,
All in the valley of Death
    Rode the six hundred.
"Forward, the Light Brigade!
"Charge for the guns!" he said:
Into the valley of Death
    Rode the six hundred.

2
"Forward, the Light Brigade!"
Was there a man dismay'd?
Not tho' the soldier knew
    Someone had blunder'd:
Theirs not to make reply,
Theirs not to reason why,
Theirs but to do and die:
Into the valley of Death
    Rode the six hundred.

3
Cannon to right of them,
Cannon to left of them,
Cannon in front of them
    Volley'd and thunder'd;
Storm'd at with shot and shell,
Boldly they rode and well,
Into the jaws of Death,
Into the mouth of Hell
    Rode the six hundred.

4
Flash'd all their sabres bare,
Flash'd as they turn'd in air,
Sabring the gunners there,
Charging an army, while
    All the world wonder'd:
Plunged in the battery-smoke
Right thro' the line they broke;
Cossack and Russian
Reel'd from the sabre stroke
    Shatter'd and sunder'd.
Then they rode back, but not
    Not the six hundred.

5
Cannon to right of them,
Cannon to left of them,
Cannon behind them
    Volley'd and thunder'd;
Storm'd at with shot and shell,
While horse and hero fell,
They that had fought so well
Came thro' the jaws of Death
Back from the mouth of Hell,
All that was left of them,
    Left of six hundred.

6
When can their glory fade?
O the wild charge they made!
    All the world wondered.
Honour the charge they made,
Honour the Light Brigade,
    Noble six hundred.
```
