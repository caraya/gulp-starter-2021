# story notes

* Full man/machine interface like in GITS
  * Brain cyberization 
  * Full prosthetic bodies with neural interface
    * Consequences
      * Have and have nots in terms of conversions
      * Social aspects
      * How does this change the world
  * Better augmented reality
    * Fully immersive cyberspace / metaverse
  * Bionics
    * How far can we take the work of Hugh Herr?
    * US Robots and Mechanical Men?
* Changed cities for changed people
* Corporate takeovers of many countries
  * Political consequences
  * Social consequences
  * Economical consequences
  * Avoidable conflict
* Military technology
  * How does decoupling the body affect war?
  * War by remote control
  * Cyborg soliders full or partial
    * If you know your body can be easily replaced, does the body itself looses value?
* New definition of haves and have nots
  * If you're a soldier, who owns your cybernetic body?
  * If you work in dangerous conditions
    * Does your company own your cybernetic body if they paid for it? 
    * What happens when you quit?
* Fully realized AI
  * What happens when a machine passes the Turing Test for the first time?
  * How do machines interact with humans if the machines acts like humans?

# Links and resources

* [http://www.technologyreview.com/news/534206/a-brain-computer-interface-that-works-wirelessly/](http://www.technologyreview.com/news/534206/a-brain-computer-interface-that-works-wirelessly/)
* [https://www.youtube.com/watch?v=Z3a5u6djGnE](https://www.youtube.com/watch?v=Z3a5u6djGnE)
* [https://www.youtube.com/watch?v=76lIQtE8oDY](https://www.youtube.com/watch?v=76lIQtE8oDY)
* [https://www.youtube.com/watch?v=WlxbDnv27dc](https://www.youtube.com/watch?v=WlxbDnv27dc)
* [https://www.youtube.com/watch?v=QRt8QCx3BCo](https://www.youtube.com/watch?v=QRt8QCx3BCo)

* [http://biomech.media.mit.edu/#/](http://biomech.media.mit.edu/#/)
* [http://arstechnica.com/the-multiverse/2014/06/how-disney-built-and-programmed-an-animatronic-president/](http://arstechnica.com/the-multiverse/2014/06/how-disney-built-and-programmed-an-animatronic-president/)
* [http://www.waltdisney.org/blog/early-days-audio-animatronics%C2%A9](http://www.waltdisney.org/blog/early-days-audio-animatronics%C2%A9)
* [https://www.youtube.com/watch?v=40L3SGmcPDQ](https://www.youtube.com/watch?v=40L3SGmcPDQ)
* [https://www.oculus.com/en-us/dk2/](https://www.oculus.com/en-us/dk2/)
* [http://www.dtic.mil/get-tr-doc/pdf?AD=ADA411978](http://www.dtic.mil/get-tr-doc/pdf?AD=ADA411978)
* [https://en.wikipedia.org/wiki/Augmented_reality](https://en.wikipedia.org/wiki/Augmented_reality)


# Vignetes

AAR 2599235
ACD Combat Action Omega824
23-AUG 2115

The drones had taken off 12 hours before from a base in CONUS as it was SOP for ACD operations. 
