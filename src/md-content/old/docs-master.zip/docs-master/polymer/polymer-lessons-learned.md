## Lessons learned

### Do not create components just because

There are times when it's tempting to create custom elements just because you can. **Please avoid this temptation**.

As a project grows in complexity it becomes harder to figure out how 