http://ink.indiamos.com/2015/02/12/degristling-the-sausage-bbedit-11-edition/

