/**
 * 
* This is the nav for region based content. In the spec it goese in its own doc. 
* Until it's implemented we can fake it by adding it to the docs and setting 
* display:none either through CSSOM or css
* 
* <nav epub:type="region-based" hidden="">
*   <ol>
*     <li epub:type="panel"><a href="page1.svg#id=roi1"></a>
*     <ol>
*       <li><a href="page1.svg#id=balloon1_1"></a></li>
*       <li><a href="page1.svg#id=balloon1_2"></a></li>
*       <li><a href="page1.svg#id=balloon1_3"></a></li>
*       <li><a href="page1.svg#id=balloon1_4"></a></li>
*     </ol>
*     </li>
*     <li epub:type="panel"><a href="page1.svg#id=roi2"></a>
*       <ol>
*         <li><a href="page1.svg#id=balloon2_1"></a></li>
*         <li><a href="page1.svg#id=balloon2_2"></a></li>
*       </ol>
*     </li>
*   </ol>
* </nav>
* 
* 



*/