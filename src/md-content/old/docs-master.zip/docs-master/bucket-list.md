## **Updated 08/07/15**. 

[The original bucket list](http://rivendellweb.net/?p=229) was written in '09 and updated early in 2010, 2011 and now in 2015. Rather than change the existing list I've decided to create a brand new version with more of who I am and where I'm at now.

It's been a while since I've looked at the list and it's surprising how little things have changed. Some of the most surprising changes is what's been taken away and not being sure of why or if I really don't want to do that anymore. While I haven't changed my mind about endurance sports I have changed my mind whether I want to do a full Ironman or not and at what point do I want to do it, if I decide I want to after all.


**Updated 10/16/11**. There have been some changes. I broke my leg in a cycling accident at the end of August. There is no way I can get back to speed quick enough to resume the training at the volume and intensity needed to complete Arizona (hell, my teammates in Georgia have completed 5 century rides in the last month!) but it happened for a reason. I have multiple plans for recovery and what will I do if I can't make an Ironman (or Iron Distance race as the case may be) for 2012 :) 

[The original bucket list](http://rivendellweb.net/?p=229) was written in '09 and updated early in 2010. Rather than change the existing list I've decided to create a brand new version with more of who I am and where I'm at now.

5. Scuba Diving
    * Basic license
    * Underwater photography
    * Whatever license you need to get to be able to explore submerged wrecks
    * Dive Master
    * Diving Instructor
6. Vegas for one of Armin's residences
7. Attend one Tiësto concert anywhere in the world
12. Learn to play piano
13. Driver’s license
    * Buy a car
14. Travel with a purpose
    * Chile to do Ironman Pucón and to do family patching
    * Australia to dive the great reef
    * Basque Country
    * England
    * Eastern Europe / Russia
    * Hawaii to enjoy at least a week there
    * Seatle
16. Go to Gencon, origins, Kublacon and Games Day at least every other year
17. Learn to Swing dance and Tango
18. Work back into Naginata
19. Train in Kyudo
20. Run the bulls before it's outlawed
21. Long distance swim
    * BB to GGB?
4. Triathlons
    * Ironman (Vineman? When?)
    * The San Diego Triathlon Challenge, sponsored by the [Challenged Athletes Foundation](http://www.challengedathletes.org/)
15. Save enough money that I can do all of these things
