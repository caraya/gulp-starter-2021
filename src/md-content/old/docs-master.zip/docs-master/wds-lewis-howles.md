# Lewis Howles

[video for animal from def leppard in the round 1987]

I still fell part of that cycle of stupid macho attitudes when growing up. You never backed down from a fight, you always stood on your own two feet. I was never the kid who did sports or who was a soccer or rugby player, I was the theater kid and I was more into arts, story telling and performance rather than physical activity.

But I still grew up not being expressive of my real feelings. It was all performance. Sure I cried when I got beat up but even that was a performance put for the bennefit of others who assumed I was crying because of pain when I was seething inside wondering what I was going to do to get even.

## Driven to achieve more than anything else

As I grew up I had to prove I could do better and I could be more perfect than everyone else. My mom taught at the same Catholic school I attended all 12 years (Saint George's College in Santiago, CL) and all the teachers I had throughout most of my school saw me as a colleague's child and some of them went way beyond what's acceptable.

So I always thought that I had to do better than everyone to prove naysayers that I earned the grades and I earned the extra curricular activities I did earn rather than have them handed to me for who my mom was.

And strangely enough I never grew out of that. When I started working in the adult world I had to do it better because I was the new guy, then I had to do it because I was the most experienced member of the team, then it was because my boss had no clue what the hell was going on, then it was because I had to be perfect in order to keep the job....

See a pattern?

It has taken me over 40 years to accept that maybe good enough is sufficient; That my good enough is just as good as other people's very best. Not to sound arrogant, but I'm good at what I do and I'm finally starting to believe that.

It has taken me about as long to accept that failure can also be a learning experience and maybe even a better learning experience than success.

Success v. failure has always been a delicate subject for me. I've always felt that if things were not perfect I had failed and I had let the people who supported me and trusted me down in such a horrible way that they would never ever want to talk to me again. Surprisingly people around me, with few exceptions, were a lot more forgiving than I was of myself.

<pre>Do you know what's worth fighting for
What is not worth dying for
Does it take your breath away
and you feel yourself suffocating

Does the pain weigh out the pride
And you look for a place to hide
Did someone break your heart inside
You're in ruins

21 Guns - From American Idiot</pre>

## Who are you?

Another take on the most deceptive question in the world. The truth is that I'm just meeting Carlos. I'm learning what makes him tick and what he's passionate about.

## Why do we bottle feelings inside? 
## What makes it so hard to express them?

What’s holding you back
