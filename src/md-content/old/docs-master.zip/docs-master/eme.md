# Danger, Will Robisnon: Encrypted Video has Arrived

I had a very interesting conversation with [Rey Bango](https://twitter.com/@reybango)
