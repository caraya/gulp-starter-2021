# Tools/Technologies to work on for the next 6 to 12 months

1. Typography

I want to keep picking tools and techniques to work displaying text on the web. 

2. Polymer

Now that, I think, I'm getting a handle on Polymer 1.0 I want to explore what we can really do with it. 

3. SVG

Graphics... in XML... oh, my

4. ebook creation

explore epub zero and see how can you implement those behaviorts today
