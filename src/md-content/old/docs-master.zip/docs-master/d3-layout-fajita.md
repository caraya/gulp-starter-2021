# d3.layouts.fajitas() for the web

In his presentation at SFHTML5 All About D3 Elijah Meeks used a very interesting metaphor to describe D3. Paraphrasing:

> If you have a `d3.layouts.fajitas()` and you give it peppers and chicken it will not give you fajitas. It may give you sliced peppers and diced chicken but building the fajita and how you build it is up to you.

[youtube=https://www.youtube.com/watch?v=yEVbE8ZQsD4&w=500]

