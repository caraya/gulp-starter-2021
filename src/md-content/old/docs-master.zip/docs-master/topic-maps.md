---
title: Creating and Using Topic Maps to Aid discoverability
date: 2014-10-22
category: Technology
status: draft
---

# Creating and Using Topic Maps to Aid discoverability

## What is a topic map?

## Why is this necessary/useful/important?

### Searchability

[Semantic search with topic maps](http://www.slideshare.net/larsga/semantic-search-with-topic-maps-2534371)

## Building the topic map

### Tools

### References

