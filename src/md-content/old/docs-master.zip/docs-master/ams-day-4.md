# AMS - Day 4 Code Overload / The moment

Conferences are some of the most exhilarating and most exhausting times for me. 

On the one hand I'm usually hungover from the night before. On the other hand I'm still hoping to get my laptop back form Apple so I can review code with people who actually know what they're doing. And these 1-day conferences are so intensive and so content-dense that they drain you even more. 

The content is amazing and the after party was even better :D



# AMS - Day 5 - Walking around town in search of sunrise

```
So we just hold on fast
Acknowledge the past 
as lessons exquisitely crafted
Painstaikingly drafted
to carve as instruments that play the music of life

for we don't realize
our faith in the prize
unless it's been somehow elusive 
How simply we choose it
the sacred simplicity 
of you at my side

vienna teng -- Eric's song
```

my legs are sore, twisted my ankle and scrapped my knee. 

# AMS - Day 6 - Reflections on life and death

I hate to turn dark in my reflections but this week it's been hard not to. Diferent channels started filtering the news that Scott Dinsmore passed away in a very freaky accident while climbing Kilimanjaro... as someone put it, the mountain claimed another warrior this week. 

I can't claim he and I were friends but he's one of the reasons why I'm writing this in Amsterdam rather than being sullen at home wondering if I would have enjoyed the event. Reading Live Your Legend and the Good Life Project

> Life turns on the more insignificant things and at the most incredible moments. I only met Scott Dinsmore in passing at WDS a few years ago.

> He's always been a model of how to live life with no compromises and on your own terms.

> He's one of the reasons why I'm writing this in Amsterdam rather than back in the bay area smile 

> He'll be missed
