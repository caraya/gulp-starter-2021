# Font Synthesis

https://drafts.csswg.org/css-fonts/#font-synthesis-prop