# Design and Philosophy

John Allsopp's [A Dao of Web Design](http://alistapart.com/article/dao) article in A List Apart is still as relevant today as it was when first written in 2000. 



<iframe src="https://player.vimeo.com/video/62462856" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> <p><a href="https://vimeo.com/62462856">Webstock &#039;13: Craig Mod - Subcompact Publishing</a> from <a href="https://vimeo.com/webstock">Webstock</a> on <a href="https://vimeo.com">Vimeo</a>.</p>




<iframe src="https://player.vimeo.com/video/34662135" width="500" height="375" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> <p><a href="https://vimeo.com/34662135">Ethan Marcotte: A Dao of Flexibility - An Event Apart</a> from <a href="https://vimeo.com/zeldman">Jeffrey Zeldman</a> on <a href="https://vimeo.com">Vimeo</a>.</p>




<iframe src="https://player.vimeo.com/video/40259368" width="500" height="375" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> <p><a href="https://vimeo.com/40259368">The CSS3 Experience | Dan Cederholm | Live at An Event Apart | Video</a> from <a href="https://vimeo.com/zeldman">Jeffrey Zeldman</a> on <a href="https://vimeo.com">Vimeo</a>.</p>


